---
name: motion-promo-video
description: Dựng video motion graphics quảng cáo / giới thiệu tính năng (MP4 có nhạc, khung dọc 9:16 hoặc ngang 16:9, 15–60s) hoàn toàn bằng code — HTML canvas vẽ từng khung, Playwright chụp, numpy tổng hợp nhạc, ffmpeg ghép. Mockup điện thoại vẽ lại giao diện app theo đúng token màu/font/câu chữ lấy từ source. Dùng skill này bất cứ khi nào người dùng muốn làm video giới thiệu app/sản phẩm, video quảng cáo Facebook/TikTok/Reels, showreel, video demo tính năng, intro logo, đổi kích thước video (9:16, 1:1), hoặc sửa lại một cảnh trong video ZCRM đã làm — kể cả khi họ chỉ nói "làm video", "làm clip", "làm reel", "video 30 giây" mà không nhắc tới công cụ.
---

# Video motion bằng code

Không có phần mềm dựng phim, không AI tạo video. Mỗi video là **một file HTML** vẽ lên `<canvas>` qua
hàm thuần `renderAt(t)` (cùng `t` → cùng hình). Nhờ vậy: sửa một chữ là xuất lại được, màu/font khớp
app thật, và soát được từng khung trước khi tốn 10 phút xuất cả video.

```
assets/template/template.html   khung chạy được ngay: mở đầu → chương có điện thoại → màn chốt CTA
assets/template/audio_template.py  nhạc khớp template (dùng scripts/audio_lib.py)
assets/fonts/                    Inter của app ZCRM (chép cạnh HTML thành fonts/)
scripts/setup.sh                 cài numpy/scipy/pillow/imageio-ffmpeg, kiểm playwright
scripts/capture.js               chụp still để soát / xuất MP4 60fps
scripts/sheet.py                 ghép still thành 1 bảng ảnh để xem nhanh
scripts/audio_lib.py             lớp Mix: nhạc nền 120 BPM + click/blip/whoosh/boom/chime
scripts/mux.sh                   ghép hình + nhạc, nén đúng cỡ đăng mạng xã hội
references/zcrm-design-tokens.md token + nơi lấy trong repo + tính năng đã xác minh
references/lessons.md            lỗi đã gặp, bố cục & nhịp đã được duyệt — ĐỌC trước khi dựng
references/examples/             4 video đã làm (promo2.html là mẫu đầy đủ nhất)
```

## Quy trình

### 1. Chốt kịch bản trước khi viết code
- Hỏi (hoặc suy từ yêu cầu): độ dài, khung (9:16 cho Reels/TikTok/quảng cáo FB; 16:9 cho YouTube/web),
  các tính năng/cảnh, lời kêu gọi cuối (CTA) và **đích của CTA** (link, hotline, QR — đừng tự bịa).
- Chia thời gian theo phách 120 BPM (bội số 0.5s). Khung 30s đã dùng: mở 0–2.5s, 2–6 chương, chốt 26.5–30s.
- Mỗi chương = tiêu đề 2 dòng + 1–3 bước ①②③; mỗi bước là một thao tác người xem hiểu được trong ~2s.

### 2. Lấy token & câu chữ TỪ SOURCE, xác minh tính năng
Làm việc trong repo app (ZaloCRM-App) nếu có. Đọc `references/zcrm-design-tokens.md` để biết tra ở đâu,
rồi tra lại thật (token có thể đã đổi): `src/theme/colors/brand.ts`, `src/i18n/vi.json`,
component liên quan. **Mỗi thao tác đưa vào video phải có trong code/i18n** — grep trước. Điều không chắc
thì nói nhẹ hoặc bỏ; đây là quảng cáo, nói sai là mất uy tín với khách.

### 3. Dựng từ template
```bash
bash <skill>/scripts/setup.sh
mkdir -p work && cd work
cp <skill>/assets/template/template.html video.html
cp -r <skill>/assets/fonts fonts
cp <skill>/assets/template/audio_template.py audio.py
```
Trong `video.html`:
- `W, H, DUR` ở đầu file; `FEATS` (chương: `t0, t1, a, b, steps`); `CTA_START`; câu mở trong `intro()`.
- Viết mỗi màn app thành `screenX(t)` vẽ bằng toạ độ **dp** (rộng 390, cao `DH`≈800) — dùng sẵn
  `header() statusBar() tabBar() avatar() btn() radio() tagPill() sheetBase() toast() photo() icon() wrap()`.
- Chuyển màn: `screenAt(t)` với `push(t, lúcChuyển, mànCũ, mànMới)`.
- Chạm tay: `tap(t, x, y)` (dp) — nhớ thêm `m.click(t)` cùng mốc trong nhạc.
- Chuyển động: `seg(t, a, b)` (0→1 trong khoảng) + easing `E.outExpo / outBack / inOutCubic / outElastic`.
- Tra dữ liệu theo **id**, không theo chỉ số mảng (xem lessons.md #1).
- Muốn học cách làm share sheet, tiến độ gửi, luồng bám đuổi, Trợ lý AI: mở `references/examples/promo2.html`
  và `promo.html`, chép hàm cần dùng.

### 4. Soát bằng still — trước khi xuất cả video
```bash
HTML=video.html node <skill>/scripts/capture.js stills 1.2 3.5 5.0 7.3 9.0 ...   # 12–24 mốc
python3 <skill>/scripts/sheet.py . 6 270        # -> sheet.png, xem bằng công cụ Read
```
Soát: chữ tràn/chồng, chip ra ngoài khung, toast đè nút, câu chữ sai, trạng thái sai thời điểm. Phóng to ô
nghi ngờ bằng cách Read still gốc. Sửa → chụp lại mốc đó. Xuất cả video ~10 phút cho 30s — đừng xuất để "xem thử".

### 5. Nhạc
Sửa `audio.py`: `m.bed(start, end)` phủ phần có điện thoại; mỗi tap → `m.click`, mỗi dấu tích/chip →
`m.blip`, mỗi chuyển chương → `m.whoosh`, xong việc → `m.chime`, cú chốt → `m.boom`, gõ chữ → `m.ticks`.
`SKILL_SCRIPTS=<skill>/scripts python3 audio.py` → `audio.wav`.

### 6. Xuất & ghép (chạy nền, ~10 phút / 30s @60fps)
```bash
HTML=video.html OUT=video_raw.mp4 DUR=30 node <skill>/scripts/capture.js video
bash <skill>/scripts/mux.sh video_raw.mp4 audio.wav ZCRM-<tên>-30s-9x16.mp4 6.5M
```
Bitrate: 30s dọc 6.5M (~23 MB), 15s ngang 14M (~24 MB); giới hạn gửi file cho người dùng là 30 MB.
Sau đó trích 3–4 khung từ MP4 (`ffmpeg -ss t -i out.mp4 -frames:v 1 x.png`) để chắc bản cuối đúng.

### 7. Giao
- Gửi MP4 (SendUserFile, display render) + gói nguồn .zip (HTML, fonts/, audio.py) để lưu trữ.
- Báo rõ: kịch bản theo mốc thời gian, token lấy từ đâu, **phần nào là dữ liệu mẫu**, phần nào đã/chưa soát
  (vd. chưa nghe nhạc), và CTA còn thiếu đích nếu người dùng chưa cho.

## Biến thể
- **Đổi 9:16 ↔ 16:9**: đừng crop — dựng lại bố cục (tiêu đề tách dòng, bộ đếm lên trên điện thoại, chip
  hai bên…). Xem cặp `examples/showreel-16x9.html` và `showreel-9x16.html`.
- **Showreel / intro logo không có điện thoại**: xem `examples/showreel-16x9.html` (dựng logo bằng đường
  gióng, chữ động có mặt nạ, cầu điểm 3D, nổ sáng → logo).
- **Kèm nội dung quảng cáo Facebook**: viết 2–3 mẫu (chính / A-B / nhắm quản lý), tiêu đề, mô tả, nút
  "Gửi tin nhắn", tin chào Messenger; chỉ nói tính năng có trong video; không ghi "miễn phí" khi chưa rõ.
