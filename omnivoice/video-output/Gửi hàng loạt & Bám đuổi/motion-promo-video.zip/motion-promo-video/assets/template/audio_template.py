"""Nhạc cho template.html (16s). Sửa các mốc cho khớp tap()/seg() trong HTML.
Chạy:  python3 audio_template.py   (cần scripts/audio_lib.py trong PYTHONPATH hoặc cùng thư mục)"""
import os, sys
sys.path.insert(0, os.environ.get('SKILL_SCRIPTS', os.path.join(os.path.dirname(__file__), '..', '..', 'scripts')))
from audio_lib import Mix

m = Mix(duration=16)
m.bed(start=2.5, end=12.1, bpm=120)                    # nhạc nền từ lúc điện thoại vào tới trước màn chốt
# mở đầu: 3 câu chữ -> 3 nhịp
m.whoosh(.05, .45, .35); m.bell(.3, 79, .14)
for i, t in enumerate([.35, .7, 1.05]): m.add(m.kick_sig(.3), t, .5); m.bell(t, [84, 88, 91][i], .1)
m.whoosh(2.45, .6, .4); m.boom(2.5, .8, .35)           # rèm kéo lên, điện thoại vào
m.whoosh(7.9 - .28, .35, .18, up=False)                # đổi chương
m.whoosh(7.9, .4, .2, pan=.4)                          # push màn
for t in [5.0]: m.click(t)                             # mỗi tap() trong HTML = một click
m.chime(5.15)                                          # toast "Đã xong"
m.blip(8.3, 79, .14)                                   # bong bóng tin hiện
# màn chốt (CTA_START = 12.15)
c = 12.15
m.whoosh(c, .5, .45); m.boom(c + .55, 1.8, .5)
m.blip(c + 1.0, 79, .14, .3); m.ticks(c + 1.5, c + 1.9, 3, .12, 1800); m.blip(c + 1.9, 84, .14, -.3)
m.boom(c + 2.25, .7, .3); m.click(c + 3.0, .5); m.bell(c + 3.02, 84, .18, 1.8)
m.save('audio.wav', fade_from=15.3)
