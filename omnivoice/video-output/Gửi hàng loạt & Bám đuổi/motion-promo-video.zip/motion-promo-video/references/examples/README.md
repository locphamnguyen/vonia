# Các video đã làm (09/2026) — mở bằng Chrome, cần thư mục `fonts/` cạnh file (chép từ assets/fonts)

| File | Video | Ghi chú |
|---|---|---|
| `showreel-16x9.html` + `showreel-audio.py` | Showreel 15s ngang: dựng logo, chữ động, hội tụ tin nhắn, cầu 3D, chốt logo | Font Be Vietnam Pro + JetBrains Mono (đã kèm trong `fonts/`, nạp qua `fonts/local.css`) |
| `showreel-9x16.html` | Bản dọc của showreel | Bố cục dựng lại cho dọc, không crop |
| `promo.html` + `audio.py` | "ZCRM Mobile" 30s: 6 tính năng (hộp thư, lọc tag, Trợ lý AI, chọn nhiều/chia sẻ, bám đuổi, tổng quan) + CTA | Nhạc: `audio.py` viết tay, cùng thư viện với `scripts/audio_lib.py` |
| `promo2.html` + `audio2.py` | 30s chi tiết: gửi hàng loạt bạn bè theo tag, nhóm theo tag, bám đuổi nhiều bước + CTA | Mẫu tốt nhất để học cách làm share sheet, tiến độ, luồng bám đuổi |

Các file `audio*.py` ở đây là bản gốc (hàm rời). Video mới nên dùng `scripts/audio_lib.py` (lớp `Mix`).
| `promo3.html` + `audio3.py` | 30s kể chuyện "Tôi chăm 200 group": soạn 1 tin trong group → chọn tin → chia sẻ 2 lượt × 100 group (rải 20 nick) → gắn kịch bản bám đuổi cho group mới → tổng kết 18:00 → CTA | Có hàm `groupChat()` dùng chung (tin nhóm, tên thành viên, nhãn "Tự động · …", ngày ngăn cách, chọn nhiều). Nhạc dùng `scripts/audio_lib.py` |
