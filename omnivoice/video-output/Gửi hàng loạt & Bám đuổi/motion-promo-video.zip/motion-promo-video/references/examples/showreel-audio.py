import numpy as np, wave
from scipy.signal import butter, sosfilt, fftconvolve
SR=48000; D=15.0; N=int(SR*D)
L=np.zeros(N); R=np.zeros(N)
rs=np.random.default_rng(3)
def at(t): return int(t*SR)
def add(sig,t,g=1.0,pan=0.0):
    i=at(t); j=min(N,i+len(sig))
    if j<=i: return
    s=sig[:j-i]*g
    L[i:j]+=s*np.sqrt((1-pan)/2)*1.414; R[i:j]+=s*np.sqrt((1+pan)/2)*1.414
def tt(d): return np.arange(int(d*SR))/SR
def env(d,a=.005,dec=.2):
    x=tt(d); return np.minimum(1,x/a)*np.exp(-x/dec)
def bp(sig,lo,hi): return sosfilt(butter(2,[lo,hi],'band',fs=SR,output='sos'),sig)
def hp(sig,f): return sosfilt(butter(2,f,'high',fs=SR,output='sos'),sig)
def lp(sig,f): return sosfilt(butter(2,f,'low',fs=SR,output='sos'),sig)
def kick(d=.45):
    x=tt(d); f=45+110*np.exp(-x/.035); ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-x/.16)+.3*np.sin(ph*2)*np.exp(-x/.02)
def hat(): return hp(rs.standard_normal(int(.06*SR)),7000)*env(.06,.001,.018)
def pluck(f,d=.35,dec=.12):
    x=tt(d); return (np.sin(2*np.pi*f*x)+.4*np.sin(4*np.pi*f*x)+.15*np.sin(6*np.pi*f*x))*env(d,.002,dec)
def bell(f,d=1.6):
    x=tt(d); return sum(a*np.sin(2*np.pi*f*m*x)*np.exp(-x/(dec)) for m,a,dec in [(1,1,.6),(2.76,.4,.25),(5.4,.2,.12),(2,.3,.4)])*np.minimum(1,x/.002)
def whoosh(d,lo=300,hi=6000,up=True):
    n=int(d*SR); x=np.linspace(0,1,n); noise=rs.standard_normal(n)
    out=np.zeros(n); blk=1024
    for k in range(0,n,blk):
        p=x[k] if up else 1-x[k]; c=lo*(hi/lo)**p
        out[k:k+blk]=bp(noise[max(0,k-2048):k+blk],c*.6,min(c*1.6,20000))[-len(out[k:k+blk]):]
    shape=np.sin(np.pi*x)**2 if not up else x**2.2
    return out*shape
def tick(f=3000): return bp(rs.standard_normal(int(.02*SR)),f*.7,f*1.4)*env(.02,.0005,.004)
def boom(d=2.2):
    x=tt(d); f=30+70*np.exp(-x/.12); ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-x/.7)+lp(rs.standard_normal(len(x)),900)*np.exp(-x/.18)*.8
note=lambda m:440*2**((m-69)/12)
# ---- music bed 1.5 → 11.4 at 120 bpm ----
chords=[[57,60,64],[53,57,60],[48,55,60,64],[55,59,62]]  # Am F C G
roots=[45,41,48,43]
duck=np.ones(N)
for b in np.arange(1.5,11.4,.5):
    add(kick(),b,.9)
    i=at(b); k=int(.25*SR); duck[i:i+k]=np.minimum(duck[i:i+k],1-.75*np.exp(-np.arange(min(k,N-i))/SR/.08))
    add(hat(),b+.25,.18,.3)
    if int((b-1.5)*4)%4==2: add(hat(),b+.125,.1,-.3)
pad=np.zeros(N)
for bar,t0 in enumerate(np.arange(1.5,11.5,2.0)):
    ch=chords[bar%4]; d=2.05; x=tt(d)
    s=sum(sum(np.sin(2*np.pi*note(m+12)*h*x+h)/h for h in (1,2,3)) for m in ch)
    s*=np.minimum(1,x/.05)*np.minimum(1,(d-x)/.05)
    i=at(t0); j=min(N,i+len(s)); pad[i:j]+=lp(s,2200)[:j-i]
    for e in np.arange(t0,t0+2,.25):  # bass 8ths/16ths
        if e<11.4: add(lp(pluck(note(roots[bar%4]),.22,.07),600),e+.0,.55)
    for q,m in enumerate([0,2,1,2,0,2,1,2]):  # arp
        e=t0+q*.25
        if e<11.4: add(pluck(note(ch[m%len(ch)]+24),.3,.08),e,.09,(-.5,.5)[q%2])
pad*=duck*.05; L+=pad; R+=pad
# ---- scene 1
add(pluck(note(81),.8,.25),.1,.35); add(bell(note(93),1.2),.1,.12)
for i,t0 in enumerate([.45,.68,.9]): add(bell(note([76,79,83][i]),1.0),t0,.08,(-.4,0,.4)[i])
add(whoosh(.6,400,7000),.92,.35,.3)
# ---- scene 2
for i in range(11): add(tick(2500+i*150),1.8+i*.04,.35,(i/5-1))
for i,t0 in enumerate([2.75,2.87,2.97]): add(whoosh(.28,800,5000,False),t0,.3,(-.6,0,.6)[i]); add(kick(.2),t0+.12,.25)
add(whoosh(.45,4000,300,True),3.35,.2); add(whoosh(.42,200,9000),3.58,.55)
add(boom(1.0),4.0,.6); add(bell(note(69),1.5),4.0,.1)
# ---- scene 3
for i in range(13): add(tick(1800+(i%4)*300),4.05+i*.028,.3,(i/6-1))
add(whoosh(.35,3000,600,False),4.95,.2)
for i in range(13): add(tick(2200+(i%3)*300),5.3+i*.028,.3,(i/6-1))
add(whoosh(.3,500,4000),5.45,.25)
r2=np.random.default_rng(5)
for k in range(26): add(pluck(900+r2.random()*1400,.08,.015),5.85+k*.025,.08,r2.random()*2-1)
add(boom(.8),6.5,.45)
# ---- scene 4: one blip per arriving bubble (pentatonic)
pent=[69,72,74,76,79,81,84]
for k in range(16):
    ta=6.8+k*.082+.015
    add(whoosh(.35,300,3000),ta-.35,.05,(-1)**k*.6); add(pluck(note(pent[k%7]+12),.25,.06),ta,.12,(-1)**k*.3)
add(whoosh(.45,300,8000),9.05,.45)
add(boom(.9),9.5,.45)
# ---- scene 5 riser
d=1.1; x=tt(d); f=180*(8**(x/d)); ph=2*np.pi*np.cumsum(f)/SR
riser=(np.sin(ph)*.3+whoosh(d,200,12000))*(x/d)**2
add(riser,10.32,.5)
for i in range(20): add(tick(1500+i*200),10.9+i*(.5/20)*(1-i/40),.25,((-1)**i)*.7)
L[at(11.42):at(11.5)]*=np.linspace(1,0,at(11.5)-at(11.42)); R[at(11.42):at(11.5)]*=np.linspace(1,0,at(11.5)-at(11.42))
# ---- scene 6
add(boom(2.8),11.5,1.0); add(hp(rs.standard_normal(int(.5*SR)),2000)*env(.5,.001,.12),11.5,.35)
for m in [57,64,69,72,76]: add(bell(note(m),3.0),11.5,.07)
for i,t0 in enumerate([11.98,12.06,12.12]): add(kick(.25),t0+.1,.45); add(whoosh(.2,1000,6000,False),t0,.2,(-.5,0,.5)[i])
add(bell(note(88),2.2),12.4,.3); add(bell(note(95),2.0),12.45,.12)
for i in range(4): add(tick(2000+i*400),12.5+i*.07,.4,(i/1.5-1))
add(whoosh(.8,2000,12000),13.8,.12)
for i,m in enumerate([81,84,88,93]): add(bell(note(m),1.2),13.9+i*.12,.05,(i/1.5-1))
x=tt(3.5); s=sum(np.sin(2*np.pi*note(m)*x)+.3*np.sin(4*np.pi*note(m)*x) for m in [45,52,57,60,64,69])
add(lp(s,1800)*np.minimum(1,x/.4)*np.minimum(1,(3.5-x)/1.2),11.5,.05)
# ---- reverb + master
ir_t=tt(1.6); ir=rs.standard_normal(len(ir_t))*np.exp(-ir_t/.35); ir=lp(ir,6000); ir/=np.abs(ir).sum()**.5*8
L=L+fftconvolve(L,ir)[:N]*.5; R=R+fftconvolve(R,ir[::-1].copy()[::-1])[:N]*.5
fade=np.ones(N); fade[at(14.4):]=np.linspace(1,0,N-at(14.4)); L*=fade; R*=fade
m=np.tanh(np.stack([L,R],1)*1.2); m/=np.abs(m).max()/0.89
with wave.open('audio.wav','wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((m*32767).astype('<i2').tobytes())
print('ok')
