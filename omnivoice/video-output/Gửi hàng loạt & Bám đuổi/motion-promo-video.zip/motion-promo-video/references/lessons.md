# Bài học từ 4 video đã làm (đọc trước khi dựng video mới)

## Lỗi đã gặp và cách tránh
1. **Lấy dữ liệu theo chỉ số mảng rồi chèn thêm phần tử** → AI "gõ" nhầm tin của khách
   (`MSGS[2].text` thành tin khác sau khi thêm 2 tin cũ). Luôn tra theo id: `MSGS.find(m => m.id === 'c')`.
2. **Hai dòng chữ đổi chỗ cùng một baseline** chồng lên nhau giữa chừng. Dòng cũ phải ra hết
   (~0.3s) rồi dòng mới mới vào; hoặc để hai dòng ở hai baseline khác nhau.
3. **Chip/chữ bay ra ngoài khung dọc**: lề hai bên điện thoại chỉ ~200px. Luôn kẹp
   `x = max(18, min(W - 18 - w, x))` và giảm cỡ chữ.
4. **Toast đè lên nút vừa bấm**: đặt toast ở đáy màn (DH - 58), không đặt giữa.
5. **Font không lên**: `url()` trong CSS tính theo vị trí file CSS, không theo HTML. Để font cùng thư mục
   `fonts/` cạnh HTML và `@font-face{src:url(fonts/Inter-600-20.ttf)}`; chờ `document.fonts.load` trước khi chụp.
6. **Chữ "Xong" bị che bởi dấu tích**: đo `measureText` trước khi đặt icon cạnh chữ căn phải.
7. **File > 30 MB** không gửi qua SendUserFile được: 30s dọc dùng 6.5 Mbps (~23 MB); 15s ngang 14 Mbps.
8. **Quảng cáo tính năng chưa có**: trước khi đưa bước nào vào video, grep code/i18n xác minh. Điều chưa
   chắc thì nói nhẹ ("báo bạn ngay") hoặc bỏ. Số liệu, tên khách, tên nhóm là dữ liệu MẪU — nói rõ với người dùng.
9. **CTA "Inbox ngay" chưa có đích**: hỏi người dùng link/hotline/QR; đừng tự bịa số điện thoại hay URL.
   Không ghi "miễn phí" nếu chưa biết trial có thu phí.

## Nhịp và bố cục đã được duyệt
- 120 BPM, mỗi cắt cảnh rơi đúng phách (bội số 0.5s). Khung 30s: mở 0–2.5/3, các chương, chốt 26.5–30.
- Khung dọc 1080×1920: thanh tiến độ kiểu Stories (y=64), logo + "ZCRM Mobile" (y≈140), tiêu đề 2 dòng
  64–70px (navy + xanh), nhãn bước ①②③ (y≈428), điện thoại 680×1360 từ y=500.
- Chuyển màn trong app dùng push kiểu iOS (màn cũ lùi 120px + tối đi, màn mới trượt từ phải).
- Mỗi thao tác có ngón tay chạm (`tap(t,x,y)`) + tiếng click cùng mốc.
- Màn chốt: nền xanh loang, logo nảy, "Sẵn sàng thử ZCRM?", 1 cặp tin chat xin trial, nút INBOX NGAY nhịp
  vòng sáng + ngón tay bấm, dòng 3 lợi ích.

## Kiểm tra trước khi xuất cả video (bắt buộc, rẻ hơn nhiều so với xuất lại 10 phút)
- Chụp 12–24 still ở các mốc chuyển động (`capture.js stills …`), ghép `sheet.py`, xem bằng Read.
- Phóng to 3–4 ô đáng ngờ (mở still gốc cỡ 540px).
- Sau khi xuất, trích lại 3–4 khung từ MP4 bằng ffmpeg `-ss t -frames:v 1` để chắc bản cuối đúng.
- Nói thật với người dùng phần nào đã xem, phần nào chưa (vd. chưa nghe nhạc).
10. **Con số trong câu chuyện phải khớp hạn mức**: trước khi viết "200 group trong 1 ngày", tính theo bảng
    giới hạn ở `zcrm-design-tokens.md` (100 nhóm/lượt, 10 nhóm/nick/ngày, 200 tin 1-1/nick/ngày) và cho
    video thể hiện đúng cách đạt được (2 lượt, rải qua 20 nick).
11. **Video kể chuyện** (vd. `examples/promo3.html` — "Tôi chăm 200 group"): mở bằng nỗi đau + con số
    (200 chấm nhấp nháy), tiêu đề chương theo mốc giờ trong ngày (7:30 → 18:00), kết bằng "tôi chỉ việc
    trả lời khách" rồi CTA hỏi thẳng người xem ("Muốn chăm group như tôi?").
