# Token thiết kế ZCRM Mobile — lấy từ đâu, dùng thế nào

Lấy TỪ SOURCE mỗi lần làm (token có thể đã đổi), đừng chép số trong file này làm chân lý.
File này ghi chỗ tìm + giá trị tại thời điểm 09/2026 để đối chiếu.

| Token | Giá trị (09/2026) | Nguồn trong repo ZaloCRM-App |
|---|---|---|
| Nền header, màu thương hiệu | `#1786BE` | `src/theme/colors/brand.ts` → `header` |
| Nền trang | `#F2F4F5` | `brand.page` |
| Thẻ nội dung | `#FFFFFF` | `brand.card` |
| Navy logo / avatar không ảnh | `#0E445A` | `brand['avatar-fallback']` |
| Nền khung chat | `#E2E9F1` | `brand['chat-canvas']` |
| Bong bóng tin gửi | nền `#D0F0FE`, viền `#0D8AFD` | grep `d0f0fe` trong `src/screens/chat-screen` |
| Bong bóng tin nhận | nền trắng, viền `#D8D8D9` | như trên |
| Chữ chính / phụ | `#212121` / `#5A6478` | message components |
| Xanh lá / đỏ | `#16A34A` / `#E13D45` | message components |
| Nhãn người gửi (tên NV) | `#3D5A6C`, chấm tên `#7FB7D6` | `OutboundSenderLabel.tsx` |
| Thanh chọn nhiều tin | Lưu `#39A9D6`, Chia sẻ `#4C9BEA`, Thu hồi `#E07A2F`, Xoá `#D93F3F` | `MessageSelectionBar.tsx` (có sẵn path SVG) |
| Font | Inter 400/420/500/580/600 | `src/assets/fonts/Inter-*.ttf` (đã chép vào `assets/fonts/`) |
| Logo | bong bóng chat navy + chữ Z trắng + chấm xanh có viền | `assets/icon.png`; bản vector nằm trong `drawLogo()` của template |

## Câu chữ giao diện
Mọi nhãn nút, tiêu đề màn, thông báo lấy từ `src/i18n/vi.json`. Cách tra nhanh:
```bash
python3 - <<'P'
import json; d=json.load(open('src/i18n/vi.json'))
def walk(o,p=''):
    if isinstance(o,dict):
        for k,v in o.items(): yield from walk(v,p+'.'+k if p else k)
    else: yield p,o
for k,v in walk(d):
    if k.startswith(('SHARE','FOLLOW_UP','COPILOT')): print(k,'=',v)
P
```
Nhóm khoá hữu ích: `COPILOT.*` (trợ lý AI), `SHARE.*` (chia sẻ/gửi hàng loạt, tiến độ, lỗi người nhận),
`FOLLOW_UP.*` (bám đuổi), `CONVERSATION.*`, `FILTER.*`. Biến cá nhân hoá: `src/constants/templateVariables.ts`
(`{gender}`, `{name}`, `{crm_full}`…).

## Tính năng đã xác minh có trong app (09/2026)
- Hộp thư gộp nhiều nick, tab Chính/Ưu tiên, lọc theo tag (mỗi tag một hàng, nút "Bỏ lọc"/"Lọc (n)").
- Trợ lý AI: bấm icon → phân tích → gợi ý vào ô soạn (anh Lộc chốt: KHÔNG có menu, nhân viên chỉ bấm gửi).
- Chọn nhiều tin → Lưu vào Kho / Chia sẻ / Thu hồi / Xoá; chia sẻ hàng loạt tối đa 19 tin.
- Khối tin (block editor) có biến `{gender}` `{name}`; Chia sẻ có tab Bạn bè/Nhóm, "Phân loại" (lọc theo tag),
  "Chọn tất cả (N)", ước tính "N người · M nhóm · dự kiến X ngày", "Đã lên lịch gửi…", Tiến độ chia sẻ,
  "Đang chờ quota hoặc giờ gửi", danh sách người nhận lỗi kèm lý do.
- Bám đuổi: "Bước 1/2 · Chọn 1 kịch bản có sẵn", "Bước 2/2 · Ghi lý do", "Xác nhận bắt đầu", thẻ luồng
  Đang chạy/Tạm dừng/Xong, "Gửi bước tiếp ngay", "Tạm dừng 24h", "Theo dõi khách này".
- Nhãn tên nhân viên trên tin gửi đi (một nick nhiều NV).
- CHƯA xác minh: luồng bám đuổi tự dừng khi khách trả lời → đừng quảng cáo điều này.

## Giới hạn thật phải tôn trọng khi kể số liệu (đã sai một lần — video 2 bản đầu)
| Giới hạn | Giá trị (09/2026) | Nguồn |
|---|---|---|
| Nhóm tối đa mỗi lần chia sẻ | 100 | `src/utils/shareSelection.ts` → `SHARE_MAX_GROUPS` (khớp server `MaxGroupsPerCampaign`) |
| Nhóm mỗi nick mỗi ngày | 10 | `shareTargets.ts` → `GROUP_DAY_CAP` |
| Tin 1-1 mỗi nick mỗi ngày | 200 (có lời nhắn kèm thì tính 2) | `shareTargets.ts` → `DM_DAY_CAP` |
| Ước tính "dự kiến N ngày" | max theo từng nick: ceil(nhóm/10), ceil(người/200) | `estimateDays` trong `shareTargets.ts` |
Ví dụ đúng: 200 group trong 1 ngày ⇒ 2 lượt × 100 và ≥ 20 nick. 248 người trong 1 ngày ⇒ ≥ 2 nick.
Bám đuổi (follow-up) trong app hiện gắn theo KHÁCH (contacts/{cid}); "bám đuổi cho cả group" là tính
năng anh Lộc xác nhận có/sắp có (09/2026) — dựng theo mô tả, nói rõ màn đó dựng theo mô tả chứ không lấy từ app.
Tin do kịch bản gửi hiện nhãn "Tự động · <tên kịch bản>" (màu #B45309, icon bánh răng).
