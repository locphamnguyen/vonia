// Chụp từng khung của một trang HTML có window.renderAt(t) + window.ready, rồi
// (a) lưu ảnh tĩnh ở các mốc để soát, hoặc (b) đẩy thẳng PNG vào ffmpeg thành MP4.
//
//   node capture.js stills 1.2 3.5 8.0          -> still_<t>.png cạnh file HTML
//   node capture.js video                         -> $OUT (mặc định video.mp4)
//
// Biến môi trường: HTML (mặc định template.html), OUT, DUR (giây, mặc định 15),
// FPS (mặc định 60), FF (đường dẫn ffmpeg; mặc định lấy từ imageio-ffmpeg).
const path = require('path');
const { spawn, execSync } = require('child_process');
function loadPlaywright() {
  try { return require('playwright'); } catch (_) {}
  const root = execSync('npm root -g').toString().trim();
  return require(path.join(root, 'playwright'));
}
const { chromium } = loadPlaywright();
const [mode, ...rest] = process.argv.slice(2);
const html = path.resolve(process.env.HTML || 'template.html');
const ff = process.env.FF || execSync(`python3 -c "import imageio_ffmpeg as i;print(i.get_ffmpeg_exe())"`).toString().trim();
(async () => {
  const b = await chromium.launch({ args: ['--allow-file-access-from-files'] });
  const p = await b.newPage({ viewport: { width: 1080, height: 1080 } });
  p.on('pageerror', e => console.log('PAGE ERROR:', e.message));
  await p.goto('file://' + html + '?capture');
  await p.evaluate(() => window.ready);
  const shot = async () => Buffer.from((await p.evaluate(() => document.getElementById('c').toDataURL('image/png'))).split(',')[1], 'base64');
  if (mode === 'stills') {
    for (const t of rest) {
      await p.evaluate(t => renderAt(t), +t);
      require('fs').writeFileSync(path.join(path.dirname(html), `still_${t}.png`), await shot());
    }
  } else {
    const fps = +(process.env.FPS || 60), n = Math.round((+process.env.DUR || 15) * fps);
    const out = process.env.OUT || 'video.mp4';
    const enc = spawn(ff, ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'png', '-i', '-',
      '-c:v', 'libx264', '-preset', 'slow', '-crf', '15', '-pix_fmt', 'yuv420p', out], { stdio: ['pipe', 'inherit', 'inherit'] });
    for (let f = 0; f < n; f++) {
      await p.evaluate(t => renderAt(t), f / fps);
      if (!enc.stdin.write(await shot())) await new Promise(r => enc.stdin.once('drain', r));
      if (f % 120 === 0) console.log(`frame ${f}/${n}`);
    }
    enc.stdin.end(); await new Promise(r => enc.on('close', r));
    console.log('done', out);
  }
  await b.close();
})();
