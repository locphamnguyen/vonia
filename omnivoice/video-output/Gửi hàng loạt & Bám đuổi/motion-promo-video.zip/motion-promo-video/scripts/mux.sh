#!/usr/bin/env bash
# Ghép hình + nhạc thành MP4 đăng mạng xã hội, giữ dưới 30 MB cho 30s 1080p60.
#   mux.sh video.mp4 audio.wav out.mp4 [bitrate=6.5M]
# Bitrate: 30s dọc 1080x1920 -> 6.5M ≈ 23 MB. 15s ngang -> 14M ≈ 24 MB. Bản nhẹ: 3M.
set -e
FF=${FF:-$(python3 -c "import imageio_ffmpeg as i;print(i.get_ffmpeg_exe())")}
BR=${4:-6.5M}
"$FF" -v error -y -i "$1" -i "$2" -c:v libx264 -preset slow -b:v "$BR" -maxrate 10M -bufsize 16M \
  -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart "$3"
"$FF" -i "$3" 2>&1 | grep -E "Duration|Video:|Audio:" || true
ls -la "$3"
