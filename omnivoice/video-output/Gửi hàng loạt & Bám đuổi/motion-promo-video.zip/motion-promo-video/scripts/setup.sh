#!/usr/bin/env bash
# Cài đủ công cụ: numpy/scipy (nhạc), Pillow (bảng ảnh), imageio-ffmpeg (ffmpeg có libx264),
# playwright + Chromium (chụp khung). Chạy một lần mỗi máy/phiên.
set -e
pip install -q numpy scipy pillow imageio-ffmpeg 2>&1 | grep -v WARNING || true
python3 -c "import imageio_ffmpeg as i; print('ffmpeg:', i.get_ffmpeg_exe())"
if node -e "require('playwright')" 2>/dev/null || node -e "require(require('path').join(require('child_process').execSync('npm root -g').toString().trim(),'playwright'))" 2>/dev/null; then
  echo "playwright: ok"
else
  echo "playwright chưa có -> npm i -g playwright && npx playwright install chromium"
  echo "(máy đã có Chromium sẵn thì đặt PLAYWRIGHT_BROWSERS_PATH, đừng tải lại)"
fi
