"""Ghép các still_<t>.png thành một bảng ảnh để soát nhanh cả video trong 1 lần xem.

    python3 sheet.py <thư_mục> [số_cột=6] [rộng_ô=270]  -> <thư_mục>/sheet.png
Ảnh xếp theo thời gian. Xem xong nên phóng to vài ô nghi ngờ (mở still gốc).
"""
import glob, os, sys
from PIL import Image
d = sys.argv[1] if len(sys.argv) > 1 else '.'
cols = int(sys.argv[2]) if len(sys.argv) > 2 else 6
cw = int(sys.argv[3]) if len(sys.argv) > 3 else 270
fs = sorted(glob.glob(os.path.join(d, 'still_*.png')), key=lambda f: float(os.path.basename(f)[6:-4]))
if not fs: sys.exit('không có still_*.png')
w0, h0 = Image.open(fs[0]).size; ch = round(cw * h0 / w0)
rows = (len(fs) + cols - 1) // cols
sheet = Image.new('RGB', (cw * cols, ch * rows), 'white')
for i, f in enumerate(fs): sheet.paste(Image.open(f).resize((cw, ch)), ((i % cols) * cw, (i // cols) * ch))
sheet.save(os.path.join(d, 'sheet.png')); print(os.path.join(d, 'sheet.png'), len(fs), 'ảnh')
